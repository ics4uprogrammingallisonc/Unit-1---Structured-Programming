/*
 * Created by: Allison Cook
 * Created on: 01-Feb-2019
 * Created for: ICS4U Programming
 * Daily Assignment � Day #2 - Hello World
 * This program combines two strings and displays hello world
*/
public class Main {

	public static void main(String[] args) {
		//Declare the strings
		String wordOne = "Hello";
		String wordTwo = "World!";
		
		//Print the strings
		System.out.println(wordOne + " " + wordTwo);
	}
}
