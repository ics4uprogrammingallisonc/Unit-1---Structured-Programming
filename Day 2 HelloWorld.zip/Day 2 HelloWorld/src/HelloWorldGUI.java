import javax.swing.JOptionPane;

public class HelloWorldGUI {

	public static void main(String[] args) {
		//Declare the strings
			String wordOne = "Hello";
			String wordTwo = "World";
			String wordThree = "GUI";
				
		//add the string together
			String message = wordOne + " " + wordTwo + " " + wordThree;
		//Create the GUI text
			JOptionPane.showMessageDialog(null, message);
			
	}

}
